# Veershree Sales Control

Two web apps for running the Veershree Realty sales team:

| App | Folder | For | What it does |
|---|---|---|---|
| **Admin app** | `admin/` | Owner and seniors | Daily control, 24-hour follow-up list, staff cards, evening update check, weekly review, pipeline board, incentives (60/40 split) and disputes, change log, Excel (CSV) export |
| **Staff app** | `staff/` | Sales staff | Add leads, record calls, site visits, deal steps, bookings and lost leads, then **Send to Admin** as a file |

Both apps are plain HTML files. They need no server, no database and no installation, so they run free on **GitHub Pages**.

---

## How the two apps work together

```
 Admin app ──(Send leads file)──► Staff app
     ▲                                │
     │                                │  staff record calls, visits, bookings
     └──────(Send to Admin file)◄─────┘
            admin imports it in "Import files"
```

1. **Admin → staff:** In *Team & access*, tap **Send leads** next to a staff member. Send the file to them on WhatsApp. They open the Staff app → *My leads* → **Import leads from admin**.
2. **Staff work:** Staff record every call, site visit, deal step and booking as it happens.
3. **Staff → admin:** Each evening staff open *Send* → **Send to Admin** and share the file to admin on WhatsApp.
4. **Import:** Admin opens **Import files** and chooses the file. The app shows what's inside before importing. Importing the same file twice is safe: work that's already there is skipped.

---

## Put it online with GitHub Pages

1. Sign in to [github.com](https://github.com) and click **New repository**.
   - Name: `veershree-sales-control` (any name works)
   - Visibility: **Public** (on a free GitHub account, Pages works only with public repositories). Only the app code is public. Your leads and client data are never uploaded to GitHub.
   - Click **Create repository**.
2. On the new repository page, click **uploading an existing file** (or **Add file → Upload files**).
3. Unzip the download on your computer, open the `veershree-sales-control` folder and drag **everything inside it** (`index.html`, `README.md`, `.nojekyll`, `favicon.png`, and the `admin` and `staff` folders) into the GitHub page. Don't upload the zip file itself.
   - `.nojekyll` is hidden on Mac and Windows by default. If you can't see it, the apps still work without it.
4. Click **Commit changes**.
5. Go to **Settings → Pages**. Under *Build and deployment*, choose **Deploy from a branch**, pick the **main** branch and the **/ (root)** folder, then click **Save**.
6. Wait 1–2 minutes and refresh the Pages screen. Your links will be:
   - Home page: `https://YOUR-USERNAME.github.io/veershree-sales-control/`
   - Admin app: `https://YOUR-USERNAME.github.io/veershree-sales-control/admin/`
   - Staff app: `https://YOUR-USERNAME.github.io/veershree-sales-control/staff/`

To update the apps later, upload the new files the same way. GitHub replaces the old ones.

---

## Install on a phone

- **iPhone (Safari):** open the Staff app link → tap **Share** → **Add to Home Screen**.
- **Android (Chrome):** open the link → tap **⋮** → **Install app** (or **Add to Home screen**).

After that it opens like a normal app and keeps working without internet. Files are sent when the phone is back online.

---

## Where data is kept (important)

- **Admin app:** saved in the browser on the computer where you use it. Use the same browser on the same computer every day.
- **Staff app:** saved on each staff member's phone.
- Nothing is stored on GitHub or any server.

Because data lives in the browser:

- **Download a backup every week.** Admin app: *Settings → Backup → Download backup*. Staff app: *Profile → Download backup*. Keep backups somewhere safe, such as Google Drive.
- **Don't use private / incognito browsing.** The browser deletes everything when the window closes.
- **Clearing browser data erases the app data.** Restore it from a backup (*Restore backup*).
- **New computer or phone:** download a backup on the old one and restore it on the new one.

---

## Try it with sample data

Add `?demo=1` to either link (or use the *Try with sample data* buttons on the home page). Sample data is never saved, so you can click around freely.

---

## Daily routine (from the owner's role document)

| When | Owner does |
|---|---|
| Morning | Check yesterday's numbers per staff member and act on the 24-hour follow-up list (*Ask senior to act*) |
| Afternoon | Open each staff card and check today's entries |
| Evening | Import the staff files and check that everyone sent today's work |
| Weekly | Weekly review: team funnel, leaderboard, lost-lead reasons, lead sources, senior reports |

Incentive rule: the lead owner gets 60%, whoever did the site visit or moved the deal forward gets 40%, and one person doing both gets 100%. Only taking a call doesn't earn an incentive. Change the amounts in *Settings*.

---

## Files

```
veershree-sales-control/
├── index.html              Home page with links to both apps
├── README.md               This guide
├── .nojekyll               Tells GitHub Pages to serve the files as they are
├── favicon.png
├── admin/
│   ├── index.html          Admin app (single file)
│   ├── manifest.webmanifest
│   ├── sw.js               Offline support
│   └── icon-*.png, apple-touch-icon.png
└── staff/
    ├── index.html          Staff app (single file)
    ├── manifest.webmanifest
    ├── sw.js               Offline support
    └── icon-*.png, apple-touch-icon.png
```

Files sent between the apps use the same format as the Claude versions of these apps, so a file from either version can be imported into either.
